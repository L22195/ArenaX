
# ArenaX Project

مشروع لتحليل بيانات الحضور في الملاعب وتكامل مع QR و Barcode باستخدام Python.

## الملفات
- `main.py`: نقطة التشغيل الرئيسية.
- `qr_scanner.py`: ماسح QR و Barcode.
- `data/`: يحتوي على ملفات CSV للبيانات.
